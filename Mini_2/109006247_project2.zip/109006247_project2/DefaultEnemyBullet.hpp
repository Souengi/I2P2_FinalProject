#ifndef DefaultEnemyBULLET_HPP
#define DefaultEnemyBULLET_HPP
#include "Bullet.hpp"

class Enemy;
class Turret;
namespace Engine {
	struct Point;
}  // namespace Engine

class DefaultEnemyBullet : public Bullet {
public:
	explicit DefaultEnemyBullet(Engine::Point position, Engine::Point forwardDirection, float rotation, Turret* parent);
	void OnExplode(Turret* turret);
	void Update(float deltaTime) override;
};
#endif // DefaultEnemyBULLET_HPP
#pragma once
