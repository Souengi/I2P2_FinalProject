#include <allegro5/base.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
#include "BBCBullet.hpp"
#include "Group.hpp"
#include "RicardoTurret.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "RicardoEffect.hpp" /*Ricardoooo*/
const int RicardoTurret::Price = 100;
RicardoTurret::RicardoTurret(float x, float y) :
	// TODO 2 (2/8): You can imitate the 2 files: 'FreezeTurret.hpp', 'FreezeTurret.cpp' to create a new turret.
	Turret("play/turret-ricardo.png", x, y, 15, Price, 1, 69) {
	// Move center downward, since we the turret head is slightly biased upward.
	Anchor.y += 8.0f / GetBitmapHeight();
}
void RicardoTurret::CreateBullet() {
	Engine::Point diff = Engine::Point(1, 0);
	float rotation = ALLEGRO_PI / 2;
	getPlayScene()->EffectGroup->AddNewObject(new RicardoEffect(Position.x - 50, Position.y-30));
	getPlayScene()->BulletGroup->AddNewObject(new BBCBullet(Position, diff, rotation, this));
	AudioHelper::PlayAudio("gun.wav");
}
/*
void RicardoTurret::Update(float deltaTime) {
	Sprite::Update(deltaTime);
	PlayScene* scene = getPlayScene();
	if (!Enabled)
		return;
}*/
