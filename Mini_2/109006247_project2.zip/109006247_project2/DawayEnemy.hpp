#ifndef DawayENEMY_HPP
#define DawayENEMY_HPP
#include "Enemy.hpp"

class DawayEnemy : public Enemy {
public:
	DawayEnemy(int x, int y);
	void Update(float deltaTime) override;
	void CreateBullet() override;
};
#endif // DawayENEMY_HPP

