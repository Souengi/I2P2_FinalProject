#ifndef FATENEMY_HPP
#define FATENEMY_HPP
#include "Enemy.hpp"

class FatEnemy : public Enemy {
public:
	FatEnemy(int x, int y);
	void CreateBullet() override;
	void Update(float deltaTime) override;
	void Hit(float damage) override;
};
#endif // NORMALENEMY_HPP
#pragma once
