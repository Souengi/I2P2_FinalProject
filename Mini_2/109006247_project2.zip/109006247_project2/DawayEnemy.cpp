#include <string>

#include "DawayEnemy.hpp"
#include "Enemy.hpp"
#include "PlayScene.hpp"
#include "AudioHelper.hpp"
#include "DefaultEnemyBullet.hpp"
#include "Point.hpp"

DawayEnemy::DawayEnemy(int x, int y) : Enemy("play/enemy-dawai.png", x, y, 8, 150, 5, 25) {
    // TODO 2 (6/8): You can imitate the 2 files: 'NormalEnemy.hpp', 'NormalEnemy.cpp' to create a new enemy.
}

void DawayEnemy::Update(float deltaTime) {
	float remainSpeed = speed * deltaTime;
	Position.x -= (Velocity.x + 100*(5-hp)) * deltaTime;
	Position.y += Velocity.y * deltaTime;
	if (Position.x <= PlayScene::EndGridPointx * PlayScene::BlockSize + PlayScene::BlockSize / 2) {
		Hit(hp);
		getPlayScene()->Hit();
		reachEndTime = 0;
		return;
	}
	Engine::Point vec = target - Position;
	reachEndTime = (vec.Magnitude() - remainSpeed) / speed;
}

void DawayEnemy::CreateBullet() {
	Engine::Point diff = Engine::Point(1, 0);
	float rotation = ALLEGRO_PI / 2;
	getPlayScene()->BulletGroup->AddNewObject(new DefaultEnemyBullet(Position, diff, rotation, nullptr)); //wait for bullet
	//AudioHelper::PlayAudio("gun.wav");
}
