#include <allegro5/base.h>
#include <allegro5/color.h>
#include <allegro5/allegro_primitives.h>
#include <cmath>
#include <string>

#include "AudioHelper.hpp"
//#include "IceCreamBullet.hpp"
#include "Group.hpp"
#include "ExplosiveTurret.hpp"
#include "PlayScene.hpp"
#include "Point.hpp"
#include "Enemy.hpp"
#include "Collider.hpp"
const int ExplosiveTurret::Price = 70;
ExplosiveTurret::ExplosiveTurret(float x, float y) :
	// TODO 2 (2/8): You can imitate the 2 files: 'FreezeTurret.hpp', 'FreezeTurret.cpp' to create a new turret.
	Turret("play/turret-7.png", x, y, 10, Price, 0.5, 1) {
	// Move center downward, since we the turret head is slightly biased upward.
	Anchor.y += 8.0f / GetBitmapHeight();
}
void ExplosiveTurret::CreateBullet() {
	/*
	Engine::Point diff = Engine::Point(1, 0);
	float rotation = ALLEGRO_PI / 2;
	getPlayScene()->BulletGroup->AddNewObject(new IceCreamBullet(Position, diff, rotation, this));
	AudioHelper::PlayAudio("gun.wav");
	*/
}
void ExplosiveTurret::Hit(float damage) {
	hp -= damage;
	if (hp <= 0) {
		OnExplode();
		// Remove all turret's reference to target.
		/*
		for (auto& it : lockedTurrets)
			it->Target = nullptr;
		for (auto& it : lockedBullets)
			it->Target = nullptr;
		*/
		//getPlayScene()->EarnMoney(money);

		
		//it block new turret when it dead
		PlayScene* scene = getPlayScene();
		/*explotion!!!*/
		for (auto& it : scene->EnemyGroup->GetObjects()) {
			Enemy* enemy = dynamic_cast<Enemy*>(it);
			if (Engine::Collider::IsCircleOverlap(Position, CollisionRadius * 30, enemy->Position, enemy->CollisionRadius)) {
				OnExplode();
				enemy->Hit(100);
				//getPlayScene()->BulletGroup->RemoveObject(objectIterator);
				//return;
			}
		}
		getPlayScene()->TowerGroup->RemoveObject(objectIterator);
		AudioHelper::PlayAudio("explosion.wav");
		//call func to return blank tile
	}
}
void ExplosiveTurret::Draw() const {
	/*if (Preview) {
		al_draw_filled_circle(Position.x, Position.y, CollisionRadius, al_map_rgba(0, 255, 0, 50));
	}*/
	Sprite::Draw();
	al_draw_circle(Position.x, Position.y, CollisionRadius * 30, al_map_rgb(225, 0, 0), 2);
	/*if (PlayScene::DebugMode) {
		// Draw target radius.
		al_draw_circle(Position.x, Position.y, CollisionRadius, al_map_rgb(0, 0, 255), 2);
	}*/
}
