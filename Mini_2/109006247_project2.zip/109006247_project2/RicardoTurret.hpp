#ifndef RicardoTURRET_HPP
#define RicardoTURRET_HPP
#include "Turret.hpp"

class RicardoTurret : public Turret {
public:
	static const int Price;
	RicardoTurret(float x, float y);
	void CreateBullet() override;
	//void Update(float deltaTime) override;
};
#endif // RicardoTURRET_HPP
#pragma once
