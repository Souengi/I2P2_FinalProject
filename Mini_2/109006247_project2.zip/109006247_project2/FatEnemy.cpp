#include <string>

#include "FatEnemy.hpp"
#include "AudioHelper.hpp"
#include "PlayScene.hpp"
#include "DefaultEnemyBullet.hpp"
#include "Turret.hpp"
#include "Collider.hpp"

FatEnemy::FatEnemy(int x, int y) : Enemy("play/enemy-4.png", x, y, 12, 300, 10, 5) {
	// TODO 2 (6/8): You can imitate the 2 files: 'NormalEnemy.hpp', 'NormalEnemy.cpp' to create a new enemy.
}

void FatEnemy::CreateBullet() {
	Engine::Point diff = Engine::Point(1, 0);
	float rotation = ALLEGRO_PI / 2;
	getPlayScene()->BulletGroup->AddNewObject(new DefaultEnemyBullet(Position, diff, rotation, nullptr)); //wait for bullet
	//AudioHelper::PlayAudio("gun.wav");
}

void FatEnemy::Hit(float damage) {
	hp -= damage;
	if (hp <= 0) {
		//OnExplode();
		// Remove all turret's reference to target.
		for (auto& it : lockedTurrets)
			it->Target = nullptr;
		for (auto& it : lockedBullets)
			it->Target = nullptr;
		getPlayScene()->EarnMoney(money);
		for (auto& it : getPlayScene()->TowerGroup->GetObjects()) {
			Turret* turret = dynamic_cast<Turret*>(it);
			if (Engine::Collider::IsCircleOverlap(Position, CollisionRadius * 20, turret->Position, turret->CollisionRadius)) {
				OnExplode();
				turret->Hit(100);
				//getPlayScene()->BulletGroup->RemoveObject(objectIterator);
				//return;
			}
		}
		getPlayScene()->EnemyGroup->RemoveObject(objectIterator);
		AudioHelper::PlayAudio("explosion.wav");
	}
}

void FatEnemy::Update(float deltaTime) {
	float remainSpeed = speed * deltaTime;
	Position.x -= (Velocity.x - 20 * (10 - hp)) * deltaTime;
	Position.y += Velocity.y * deltaTime;
	if (Position.x <= PlayScene::EndGridPointx * PlayScene::BlockSize + PlayScene::BlockSize / 2) {
		Hit(hp);
		getPlayScene()->Hit();
		reachEndTime = 0;
		return;
	}
	//shoot bullet
	reload -= deltaTime;
	if (reload <= 0) {
		// shoot.
		reload = 2;
		CreateBullet();
	}
	/*stop at turret*/
	//get turret position and set
	PlayScene* scene = getPlayScene();
	for (auto& it : scene->TowerGroup->GetObjects()) {
		Turret* turret = dynamic_cast<Turret*>(it);
		if (Engine::Collider::IsCircleOverlap(Position, CollisionRadius, turret->Position, turret->CollisionRadius)) {
			Position.x += Velocity.x * deltaTime;
		}
	}
	Engine::Point vec = target - Position;
	reachEndTime = (vec.Magnitude() - remainSpeed) / speed;
}