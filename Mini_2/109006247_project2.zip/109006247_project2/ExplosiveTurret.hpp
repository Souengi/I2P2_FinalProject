#ifndef ExplosiveTURRET_HPP
#define ExplosiveTURRET_HPP
#include "Turret.hpp"

class ExplosiveTurret : public Turret {
public:
	static const int Price;
	ExplosiveTurret(float x, float y);
	void CreateBullet() override;
	void Hit(float damage) override;
	void Draw() const override;
};
#endif // ExplosiveTURRET_HPP
#pragma once
#pragma once
